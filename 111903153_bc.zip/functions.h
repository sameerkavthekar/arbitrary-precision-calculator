#include "list.h"

number *addNums(number *n1, number *n2);
number *subNums(number *n1, number *n2, int freeNums);
number *mulNums(number *n1, number *n2, int freeNums);
number *divNums(number *n1, number *n2, int returnRemainderOrQuotient);
number *power(number *n1, number *n2);
number *compareNums(number *n1, number *n2);